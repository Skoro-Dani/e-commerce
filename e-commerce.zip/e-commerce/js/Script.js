function SicuroDiVolerEliminare() {
    let SiONo = prompt("Sicuro di voler Eliminare il Prodotto");
    let text;
    if (SiONo == null || SiONo == "") {
        text = "User cancelled the prompt.";
    } else {
        text = "Hello " + person + "! How are you today?";
    }
}